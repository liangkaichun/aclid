#!/bin/bash
# aclid 卸载脚本 — 以 root 运行（由 aclid 功能管理器通过 osascript 提权调用）
# $1 = "revert-lock" 时，同时删除合盖锁屏相关偏好；"keep-lock" 时保留。

launchctl bootout system/com.aclid.daemon 2>/dev/null || true
rm -f /Library/LaunchDaemons/com.aclid.daemon.plist
rm -f /usr/local/bin/aclid
rm -f /var/log/aclid.log

if [ "${1:-}" = "revert-lock" ]; then
  U="$(stat -f%Su /dev/console)"
  sudo -u "$U" defaults -currentHost delete com.apple.screensaver askForPassword 2>/dev/null || true
  sudo -u "$U" defaults -currentHost delete com.apple.screensaver askForPasswordDelay 2>/dev/null || true
  echo "已还原用户 $U 的“显示器关闭后要求密码”设置"
fi

echo "已卸载：守护进程已停止，/usr/local/bin/aclid、LaunchDaemon plist 与日志已删除。"
