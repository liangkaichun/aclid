#!/bin/bash
# aclid 安装脚本 — 以 root 运行（由 aclid 功能管理器通过 osascript 提权调用）
# 步骤与上游仓库 README 一致：复制脚本与 plist，bootout 旧实例后 bootstrap 新实例，
# 并为控制台用户写入“显示器关闭后要求密码”（合盖锁屏的前提）。

set -euo pipefail

RES="$(cd "$(dirname "$0")" && pwd)"

# 1. 守护脚本
mkdir -p /usr/local/bin
install -m 755 -o root -g wheel "$RES/aclid" /usr/local/bin/aclid

# 2. LaunchDaemon（launchd 要求 root:wheel 且不可组/世界可写）
install -m 644 -o root -g wheel "$RES/com.aclid.daemon.plist" /Library/LaunchDaemons/com.aclid.daemon.plist

# 3. 重启守护进程
launchctl bootout system/com.aclid.daemon 2>/dev/null || true
launchctl bootstrap system /Library/LaunchDaemons/com.aclid.daemon.plist

# 4. 合盖锁屏设置：root 直接 defaults -currentHost 会写到 root 的偏好，
#    必须以控制台用户身份写入。
U="$(stat -f%Su /dev/console)"
sudo -u "$U" defaults -currentHost write com.apple.screensaver askForPassword -int 1
sudo -u "$U" defaults -currentHost write com.apple.screensaver askForPasswordDelay -int 0

echo "已安装 /usr/local/bin/aclid 与 /Library/LaunchDaemons/com.aclid.daemon.plist"
echo "守护进程已启动（com.aclid.daemon）"
echo "已为用户 $U 设置：显示器关闭后要求密码，延迟 0 秒"
